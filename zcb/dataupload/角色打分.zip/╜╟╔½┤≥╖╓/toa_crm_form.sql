/*
Navicat MySQL Data Transfer

Source Server         : z
Source Server Version : 50617
Source Host           : 127.0.0.1:3306
Source Database       : edu1

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2015-06-05 11:57:36
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for toa_crm_form
-- ----------------------------
DROP TABLE IF EXISTS `toa_crm_form`;
CREATE TABLE `toa_crm_form` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `formname` varchar(128) DEFAULT NULL,
  `inputname` varchar(64) DEFAULT NULL,
  `type` varchar(2) DEFAULT NULL,
  `inputvalue` varchar(128) DEFAULT NULL,
  `inputtype` varchar(2) DEFAULT NULL,
  `inputvaluenum` text,
  `confirmation` varchar(2) DEFAULT NULL,
  `type1` varchar(32) DEFAULT NULL,
  `type2` varchar(2) DEFAULT NULL,
  `inputnumber` int(11) DEFAULT NULL,
  `w` int(11) DEFAULT NULL,
  `h` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of toa_crm_form
-- ----------------------------
INSERT INTO `toa_crm_form` VALUES ('183', '银行账号', 'toa_crm_company5031_130707152058', '0', '', '1', '', '2', 'crm_company', '0', '14', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('182', '开户名称', 'toa_crm_company0773_130707152050', '0', '', '1', '', '2', 'crm_company', '0', '13', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('181', '开户行', 'toa_crm_company8222_130707152032', '0', '', '1', '', '2', 'crm_company', '0', '12', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('180', '企业法人', 'toa_crm_company3983_130707151936', '0', '', '1', '', '2', 'crm_company', '0', '7', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('175', '所属行业', 'toa_crm_company5608_130707151553', '0', '', '5', '旅游/餐饮/娱乐/休闲/购物\r\n|机械设备/通用零部件\r\n|日常服务\r\n|纺织/皮革/服装/鞋帽\r\n|家具/生活用品/食品\r\n|通信/邮政/计算机/网络\r\n|医疗保健/社会福利\r\n|电子电器/仪器仪表\r\n|金融/保险/证券/投资\r\n|交通物流/运输设备\r\n|城建/房产/建材/装潢 \r\n|石油化工/橡胶塑料\r\n|钟表眼镜/工艺品/礼品 \r\n|造纸/纸品/印刷/包装 \r\n|新闻/出版/科研/教育 \r\n|农林牧渔 \r\n|广告/会展/商务办公/咨询业 \r\n|冶金冶炼/金属及非金属制品\r\n|贸易/批发/市场 \r\n|党政机关/社会团体', '2', 'crm_company', '0', '6', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('184', '详细描述', 'toa_crm_company9083_130707152329', '0', '', '2', '', '2', 'crm_company', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('173', '客户状态', 'toa_crm_company3538_130707151232', '0', '', '5', '潜在客户|意向客户|失效客户|己成交客户|VIP客户', '2', 'crm_company', '1', '1', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('179', '注册地址', 'toa_crm_company3337_130707151924', '0', '', '1', '', '2', 'crm_company', '0', '10', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('178', '注册资本', 'toa_crm_company1407_130707151913', '0', '', '1', '', '2', 'crm_company', '0', '8', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('177', '成立时间', 'toa_crm_company0785_130707151846', '3', '', '1', '', '2', 'crm_company', '0', '9', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('176', '公司网站', 'toa_crm_company3616_130707151643', '0', '', '1', '', '2', 'crm_company', '0', '11', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('172', '客户等级', 'toa_crm_company8701_130707151018', '0', '', '3', '一星|二星|三星|四星|五星', '2', 'crm_company', '1', '2', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('171', '客户来源', 'toa_crm_company9793_130707150911', '0', '', '5', '电话来访|朋友介绍|广告推广|独立开发|促销活动|公开招标|互联网|客户介绍|代理商', '2', 'crm_company', '0', '3', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('174', '所属区域', 'toa_crm_company4128_130707151505', '0', '', '1', '', '2', 'crm_company', '0', '5', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('170', '客户类别', 'toa_crm_company8860_130707150634', '0', '', '3', '企业客户|个人客户', '2', 'crm_company', '0', '4', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('152', '产品型号', 'toa_crm_product9202_130707144537', '0', '', '1', '', '2', 'crm_product', '0', '1', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('153', '计量单位', 'toa_crm_product7824_130707144603', '0', '', '5', '台|套|只|个|公斤|斤|吨|箱|米|本|辆', '2', 'crm_product', '1', '2', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('154', '生产厂商', 'toa_crm_product4814_130707144618', '0', '', '1', '', '2', 'crm_product', '0', '4', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('155', '产地', 'toa_crm_product7603_130707144628', '0', '', '1', '', '2', 'crm_product', '0', '3', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('156', '产品图片', 'toa_crm_product6674_130707144638', '1', '', '1', '', '2', 'crm_product', '0', '5', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('157', '详细描述', 'toa_crm_product8295_130707144653', '0', '', '2', '', '2', 'crm_product', '0', '7', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('158', '产品附件', 'toa_crm_product5070_130707144824', '2', '', '1', '', '2', 'crm_product', '0', '6', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('159', '性别', 'toa_crm_contact4876_130707145252', '0', '', '3', '男|女', '2', 'crm_contact', '1', '1', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('160', '生日', 'toa_crm_contact8440_130707145325', '3', '', '1', '', '2', 'crm_contact', '0', '2', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('161', '手机', 'toa_crm_contact9124_130707145346', '0', '', '1', '', '2', 'crm_contact', '1', '4', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('162', '办公电话', 'toa_crm_contact1165_130707145357', '0', '', '1', '', '2', 'crm_contact', '1', '5', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('163', '职务', 'toa_crm_contact8466_130707145412', '0', '', '1', '', '2', 'crm_contact', '1', '3', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('164', '传真', 'toa_crm_contact4245_130707145421', '0', '', '1', '', '2', 'crm_contact', '0', '6', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('165', 'QQ/MSN', 'toa_crm_contact3648_130707145439', '0', '', '1', '', '2', 'crm_contact', '0', '7', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('166', '邮箱', 'toa_crm_contact8837_130707145451', '0', '', '1', '', '2', 'crm_contact', '1', '8', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('167', '邮编', 'toa_crm_contact9436_130707145500', '0', '', '1', '', '2', 'crm_contact', '0', '9', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('168', '地址', 'toa_crm_contact6338_130707145511', '0', '', '1', '', '2', 'crm_contact', '0', '10', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('169', '备注', 'toa_crm_contact9839_130707145550', '0', '', '2', '', '2', 'crm_contact', '0', '11', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('185', '回访目的', 'toa_crm_service5957_130707153242', '0', '', '2', '', '2', 'crm_service', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('186', '回访结果描述', 'toa_crm_service1649_130707153314', '0', '', '2', '', '2', 'crm_service', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('187', '关怀内容', 'toa_crm_care6461_130707153428', '0', '', '2', '', '2', 'crm_care', '0', '3', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('188', '关怀类型', 'toa_crm_care7981_130707153549', '0', '', '5', '节日|生日|店庆活动', '2', 'crm_care', '1', '1', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('189', '拜访效果', 'toa_crm_care9689_130707153623', '0', '', '5', '热情拥护|大力支持|支持|有兴趣|认知相同|应该不会拒绝|不感兴趣|作负面评价|拒绝你的建议|支持你的对手', '2', 'crm_care', '0', '2', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('190', '备注', 'toa_crm_care4970_130707153630', '0', '', '2', '', '2', 'crm_care', '0', '4', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('191', '投诉类型', 'toa_crm_complaints2557_130707153839', '0', '', '5', '产品投诉|售后投诉|竟见反馈', '2', 'crm_complaints', '1', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('192', '投诉方式', 'toa_crm_complaints8348_130707154007', '0', '', '5', '上门|电话|邮箱|短信|QQ|传真|网站', '2', 'crm_complaints', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('193', '处理状态', 'toa_crm_complaints5024_130707154054', '0', '', '3', '待处理|处理中|己处理', '2', 'crm_complaints', '1', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('194', '紧急状态', 'toa_crm_complaints3652_130707154131', '0', '', '3', '急|不急|非常急', '2', 'crm_complaints', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('195', '投诉内容', 'toa_crm_complaints1143_130707154150', '0', '', '2', '', '2', 'crm_complaints', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('196', '反馈内容', 'toa_crm_complaints1197_130707154201', '0', '', '2', '', '2', 'crm_complaints', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('197', '备注', 'toa_crm_complaints8873_130707154211', '0', '', '2', '', '2', 'crm_complaints', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('198', '备注', 'toa_crm_stock3050_130707154314', '0', '', '2', '', '2', 'crm_stock', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('199', '备注', 'toa_crm_purchase9787_130707154411', '0', '', '2', '', '2', 'crm_purchase', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('200', '备注', 'toa_crm_offer3897_130707154536', '0', '', '2', '', '2', 'crm_offer', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('201', '方案内容', 'toa_crm_program8539_130707154722', '0', '', '2', '', '2', 'crm_program', '0', '3', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('202', '客户反馈', 'toa_crm_program8689_130707154735', '0', '', '2', '', '2', 'crm_program', '0', '4', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('203', '其它备注', 'toa_crm_program2617_130707154751', '0', '', '2', '', '2', 'crm_program', '0', '5', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('204', '方案状态', 'toa_crm_program8897_130707154925', '0', '', '3', '准备中|己提交|未提交', '2', 'crm_program', '1', '1', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('205', '附件上传', 'toa_crm_program8426_130707154948', '2', '', '1', '', '2', 'crm_program', '0', '2', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('206', '合同描述', 'toa_crm_contract5029_130707155031', '0', '', '2', '', '2', 'crm_contract', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('207', '备注', 'toa_crm_order6622_130707155054', '0', '', '2', '', '2', 'crm_order', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('208', '备注', 'toa_crm_price7922_130707155103', '0', '', '2', '', '2', 'crm_price', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('209', '备注', 'toa_crm_payment7787_130707155114', '0', '', '2', '', '2', 'crm_payment', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('210', '银行账号', 'toa_crm_business5031_130707152058', '0', '', '1', '', '2', 'crm_business', '0', '14', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('211', '开户名称', 'toa_crm_business0773_130707152050', '0', '', '1', '', '2', 'crm_business', '0', '13', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('212', '开户行', 'toa_crm_business8222_130707152032', '0', '', '1', '', '2', 'crm_business', '0', '12', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('213', '企业法人', 'toa_crm_business3983_130707151936', '0', '', '1', '', '2', 'crm_business', '0', '7', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('214', '所属行业', 'toa_crm_business5608_130707151553', '0', '', '5', '旅游/餐饮/娱乐/休闲/购物\r\n|机械设备/通用零部件\r\n|日常服务\r\n|纺织/皮革/服装/鞋帽\r\n|家具/生活用品/食品\r\n|通信/邮政/计算机/网络\r\n|医疗保健/社会福利\r\n|电子电器/仪器仪表\r\n|金融/保险/证券/投资\r\n|交通物流/运输设备\r\n|城建/房产/建材/装潢 \r\n|石油化工/橡胶塑料\r\n|钟表眼镜/工艺品/礼品 \r\n|造纸/纸品/印刷/包装 \r\n|新闻/出版/科研/教育 \r\n|农林牧渔 \r\n|广告/会展/商务办公/咨询业 \r\n|冶金冶炼/金属及非金属制品\r\n|贸易/批发/市场 \r\n|党政机关/社会团体', '2', 'crm_business', '0', '6', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('215', '详细描述', 'toa_crm_business9083_130707152329', '0', '', '2', '', '2', 'crm_business', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('216', '代理状态', 'toa_crm_business3538_130707151232', '0', '', '5', '意向代理|正式代理商|核心代理商|暂停合作', '2', 'crm_business', '1', '1', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('217', '注册地址', 'toa_crm_business3337_130707151924', '0', '', '1', '', '2', 'crm_business', '0', '10', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('218', '注册资本', 'toa_crm_business1407_130707151913', '0', '', '1', '', '2', 'crm_business', '0', '8', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('219', '成立时间', 'toa_crm_business0785_130707151846', '3', '', '1', '', '2', 'crm_business', '0', '9', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('220', '公司网站', 'toa_crm_business3616_130707151643', '0', '', '1', '', '2', 'crm_business', '0', '11', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('221', '代理等级', 'toa_crm_business8701_130707151018', '0', '', '5', '普通代理|授权代理商|区域代理|区域代理[买断]|独家[买断]总代理', '2', 'crm_business', '1', '2', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('222', '客户来源', 'toa_crm_business9793_130707150911', '0', '', '5', '电话来访|朋友介绍|广告推广|独立开发|促销活动|公开招标|互联网|客户介绍', '2', 'crm_business', '0', '3', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('223', '代理区域', 'toa_crm_business4128_130707151505', '0', '', '1', '', '2', 'crm_business', '0', '5', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('224', '客户类别', 'toa_crm_business8860_130707150634', '0', '', '3', '企业代理|个人代理', '2', 'crm_business', '1', '4', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('225', '银行账号', 'toa_crm_supplier5031_130707152058', '0', '', '1', '', '2', 'crm_supplier', '0', '14', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('226', '开户名称', 'toa_crm_supplier0773_130707152050', '0', '', '1', '', '2', 'crm_supplier', '0', '13', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('227', '开户行', 'toa_crm_supplier8222_130707152032', '0', '', '1', '', '2', 'crm_supplier', '0', '12', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('228', '企业法人', 'toa_crm_supplier3983_130707151936', '0', '', '1', '', '2', 'crm_supplier', '0', '7', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('229', '所属行业', 'toa_crm_supplier5608_130707151553', '0', '', '5', '旅游/餐饮/娱乐/休闲/购物\r\n|机械设备/通用零部件\r\n|日常服务\r\n|纺织/皮革/服装/鞋帽\r\n|家具/生活用品/食品\r\n|通信/邮政/计算机/网络\r\n|医疗保健/社会福利\r\n|电子电器/仪器仪表\r\n|金融/保险/证券/投资\r\n|交通物流/运输设备\r\n|城建/房产/建材/装潢 \r\n|石油化工/橡胶塑料\r\n|钟表眼镜/工艺品/礼品 \r\n|造纸/纸品/印刷/包装 \r\n|新闻/出版/科研/教育 \r\n|农林牧渔 \r\n|广告/会展/商务办公/咨询业 \r\n|冶金冶炼/金属及非金属制品\r\n|贸易/批发/市场 \r\n|党政机关/社会团体', '2', 'crm_supplier', '0', '6', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('230', '详细描述', 'toa_crm_supplier9083_130707152329', '0', '', '2', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('240', '联系人', 'toa_crm_supplier0942_130710181509', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('232', '注册地址', 'toa_crm_supplier3337_130707151924', '0', '', '1', '', '2', 'crm_supplier', '0', '10', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('233', '注册资本', 'toa_crm_supplier1407_130707151913', '0', '', '1', '', '2', 'crm_supplier', '0', '8', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('234', '成立时间', 'toa_crm_supplier0785_130707151846', '3', '', '1', '', '2', 'crm_supplier', '0', '9', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('235', '公司网站', 'toa_crm_supplier3616_130707151643', '0', '', '1', '', '2', 'crm_supplier', '0', '11', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('236', '等级', 'toa_crm_supplier8701_130707151018', '0', '', '3', '一星|二星|三星|四星|五星', '2', 'crm_supplier', '1', '2', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('237', '来源', 'toa_crm_supplier9793_130707150911', '0', '', '5', '电话来访|朋友介绍|广告推广|独立开发|促销活动|公开招标|互联网|客户介绍|代理商', '2', 'crm_supplier', '1', '3', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('238', '所属区域', 'toa_crm_supplier4128_130707151505', '0', '', '1', '', '2', 'crm_supplier', '0', '5', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('239', '类别', 'toa_crm_supplier8860_130707150634', '0', '', '3', '企业客户|个人客户', '2', 'crm_supplier', '0', '4', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('241', '性别', 'toa_crm_supplier6358_130710181526', '0', '', '3', '男|女', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('242', '职务', 'toa_crm_supplier5588_130710181535', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('243', '手机', 'toa_crm_supplier3656_130710181543', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('244', '办公电话', 'toa_crm_supplier8551_130710181551', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('245', '传真', 'toa_crm_supplier7569_130710181559', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('246', 'QQ/MSN', 'toa_crm_supplier2366_130710181610', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('247', '邮箱', 'toa_crm_supplier5022_130710181617', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('248', '邮编', 'toa_crm_supplier4276_130710181623', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('249', '地址', 'toa_crm_supplier1241_130710181630', '0', '', '1', '', '2', 'crm_supplier', '0', '999', '0', '0');
INSERT INTO `toa_crm_form` VALUES ('250', '关怀角色', 'toa_crm_care9689_130707153625', '0', null, '5', '最终决策者EB|应用选型UB|技术选型TB|指导者/教练coach', '2', 'crm_care', '0', null, null, null);
