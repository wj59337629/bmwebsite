package sesingle.bean;

import javax.servlet.ServletContext;
import java.util.Hashtable;
import sesingle.model.SessionModel;
import org.apache.log4j.Logger;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;

public class SessionSingleBean {
  Logger logger = Logger.getLogger(SessionSingleBean.class);
  public SessionSingleBean() {
  }
  public boolean checkSession(HttpServletRequest request,String username)
  {
    boolean issession=true;
    Hashtable hashtable=(Hashtable)request.getSession().getServletContext().getAttribute("idlist");
    HashMap hashMap=(HashMap)request.getSession().getServletContext().getAttribute("sessionid");
    synchronized(this)
    {
      Object obj=hashtable.get(username);
      if(obj!=null)
      {
        //这里使用Hashtable因为 Hashtable本身是synchronized 所以为了方便就使用Hashtable
        //如果自己编写一个类实现了synchronized 并且只是放入String[只是验证登录名称] 效果会更好
        //如果不是null就已经可以判断出来登录了，如果想进一步判断登录信息，这里做处理
        SessionModel sessionModel=(SessionModel)obj;
        //.............
        issession=false;
      }
      else
      {
          //放入上下文
          SessionModel sessionModel=new SessionModel();
          sessionModel.setPhone("12345678");
          hashtable.put(username,sessionModel);
          hashMap.put(request.getSession().getId(),username);
          logger.info(username+"  已经填入上下文");
          logger.info(">>>>>>>>>>>>>>>>>>>>>>>>");
      }
    }
    return issession;
  }
}
