package sesingle.model;

public class SessionModel {
  private String phone;
  private String username;
  public SessionModel() {
  }

  public String getPhone() {
    return phone;
  }
  public void setPhone(String phone) {
    this.phone = phone;
  }
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }
}
