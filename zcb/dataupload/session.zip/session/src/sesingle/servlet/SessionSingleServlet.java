package sesingle.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import sesingle.bean.SessionSingleBean;
import sesingle.model.SessionModel;

public class SessionSingleServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=GBK";

  //Initialize global variables
  public void init() throws ServletException {
  }

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String stag=request.getParameter("tag");
    if(stag.equals("login"))
    {
      login(request,response);
    }
    else if(stag.equals("unlogin"))
    {
      unlogin(request,response);
    }
  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**
   * 登录
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @throws ServletException
   * @throws IOException
   */
  private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String username=request.getParameter("username");
    String pwd=request.getParameter("password");
    //默认为用户名和密码成功

    SessionSingleBean sessionSingleBean=new SessionSingleBean();
    //验证是否已经登录
    String herfpath="";
    boolean issession=sessionSingleBean.checkSession(request,username);
    if(issession)
    {
      SessionModel sessionModel=new SessionModel();
      request.getSession().setAttribute("sessionmodel",sessionModel);
      herfpath="/manager/manager.jsp";
    }
    else
    {
        request.setAttribute("info","该用户已经登录，登录失败");
        herfpath="/login/login.jsp";
    }

    RequestDispatcher requestDispatcher=request.getRequestDispatcher(herfpath);
    requestDispatcher.forward(request,response);

  }

  /**
   * 注销
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @throws ServletException
   * @throws IOException
   */
  private void unlogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    request.getSession().invalidate();
    response.sendRedirect(request.getContextPath()+"/login/login.jsp");
  }
  //Clean up resources
  public void destroy() {
  }
}
