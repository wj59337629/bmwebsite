package sesingle.listener;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import org.apache.log4j.Logger;
import sesingle.model.SessionModel;

/**
 * <p>Title: </p>
 * <p>Description: 当Session过期的时候删除Context中的对应内容</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author sunfruit
 * @version 1.0
 */
public class SessionSingleListener extends HttpServlet implements HttpSessionListener {
  Logger logger = Logger.getLogger(SessionSingleListener.class);

  //Notification that a session was created
  public void sessionCreated(HttpSessionEvent se) {

  }

  //Notification that a session was invalidated
  public void sessionDestroyed(HttpSessionEvent se) {
    HttpSession session=se.getSession();
    String id=session.getId();
    ServletContext context=se.getSession().getServletContext();

    Hashtable hashtable=(Hashtable)context.getAttribute("idlist");
    HashMap hashMap=(HashMap)context.getAttribute("sessionid");

    Object objname=hashMap.get(id);
    if(objname==null) return;
    String username=objname.toString();
    //String username="111";
    logger.info("hashtable长度 "+hashtable.size()+" hashMap的长度 "+hashMap.size());
    hashtable.remove(username);
    hashMap.remove(id);
    logger.info("Session 过期 删除Context中的 "+username +" 项");
    hashtable=(Hashtable)context.getAttribute("idlist");
    logger.info("hashtable长度 "+hashtable.size()+" hashMap的长度 "+hashMap.size());
    logger.info(">>>>>>>>>>>>>>>>>>>>>>>>");
  }
}
